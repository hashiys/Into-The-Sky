@echo off
echo "The Launcher Works!"
pause